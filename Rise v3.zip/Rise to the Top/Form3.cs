﻿using Rise_to_the_Top;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Rise
{
    public partial class Form3 : RoundedForm
    {

        public Point mouseLocation;

        public Form3()
        {
            InitializeComponent();
            ForlornApi.Api.InitializeForlorn();
        }

        private void realistbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            Editor3.Text = File.ReadAllText($"./Scripts/{realistbox.SelectedItem}");
        }

        class functions
        {
            public static void PopulateListBox(System.Windows.Forms.ListBox lsb, string Folder, string FileType)
            {
                DirectoryInfo dinfo = new DirectoryInfo(Folder);
                FileInfo[] Files = dinfo.GetFiles(FileType);
                foreach (FileInfo file in Files)
                {
                    lsb.Items.Add(file.Name);
                }
            }
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Close();
        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            realistbox.Items.Clear();
            functions.PopulateListBox(realistbox, "./Scripts", "*.lua");
            functions.PopulateListBox(realistbox, "./Scripts", "*.txt");
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void Editor3_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button10_Click(object sender, EventArgs e)
        {

        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y);
        }

        private void panel2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition;
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose;
            }
        }

        private void execute_Click(object sender, EventArgs e)
        {
            ForlornApi.Api.ExecuteScript(Editor3.Text);        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Editor3.Clear();
        }

        private void guna2HtmlLabel2_Click(object sender, EventArgs e)
        {

        }
    }
}
