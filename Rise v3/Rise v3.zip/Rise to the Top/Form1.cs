﻿using Microsoft.Win32;
using Rise;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Rise_to_the_Top
{
    public partial class Form1 : RoundedForm
    {

        public Point mouseLocation;

        public Form1()
        {
            InitializeComponent();
            Timer time = new Timer();
            time.Tick += timertick;
            time.Start();
            ForlornApi.Api.InitializeForlorn();
        }   

        private void timertick(object sender, EventArgs e)
        {

            if (ForlornApi.Api.IsInjected())
            {
                realstatus.Text = "Status: ⭕";
                realstatus.ForeColor = Color.LightGreen;  // Change text color to green
            }
            else
            {
                realstatus.Text = "Status: ⭕";
                realstatus.ForeColor = Color.Red;  // Change text color to red
            }
        }



        private void button1_Click(object sender, EventArgs e)
        {
            ForlornApi.Api.Inject();
        }


        private async void Form1_Load(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            wc.Proxy = null;
            try
            {
                RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Internet Explorer\\Main\\FeatureControl\\FEATURE_BROWSER_EMULATION", true);
                string friendlyName = AppDomain.CurrentDomain.FriendlyName;
                bool flag2 = registryKey.GetValue(friendlyName) == null;
                if (flag2)
                {
                    registryKey.SetValue(friendlyName, 11001, RegistryValueKind.DWord);
                }
                registryKey = null;
                friendlyName = null;
            }
            catch (Exception)
            {
            }
            webBrowser1.Url = new Uri(string.Format("file:///{0}/Monaco/Monaco.html", Directory.GetCurrentDirectory()));
            await Task.Delay(500);
            webBrowser1.Document.InvokeScript("SetTheme", new string[]
            {
           "Dark"
            });
            addBase();
            addMath();
            addGlobalNS();
            addGlobalV();
            addGlobalF();
            webBrowser1.Document.InvokeScript("SetText", new object[]
            {
         "~~Rise to the Top~~"
            });
        }
        WebClient wc = new WebClient();
        private string defPath = Application.StartupPath + "//Monaco//";

        private void addIntel(string label, string kind, string detail, string insertText)
        {
            string text = "\"" + label + "\"";
            string text2 = "\"" + kind + "\"";
            string text3 = "\"" + detail + "\"";
            string text4 = "\"" + insertText + "\"";
            webBrowser1.Document.InvokeScript("AddIntellisense", new object[]
            {
    label,
    kind,
    detail,
    insertText
            });


        }

        private void addGlobalF()
        {
            string[] array = System.IO.File.ReadAllLines(this.defPath + "//globalf.txt");
            foreach (string text in array)
            {
                bool flag = text.Contains(':');
                if (flag)
                {
                    this.addIntel(text, "Function", text, text.Substring(1));
                }
                else
                {
                    this.addIntel(text, "Function", text, text);
                }
            }
        }

        private void addGlobalV()
        {
            foreach (string text in System.IO.File.ReadLines(this.defPath + "//globalv.txt"))
            {
                this.addIntel(text, "Variable", text, text);
            }
        }

        private void addGlobalNS()
        {
            foreach (string text in System.IO.File.ReadLines(this.defPath + "//globalns.txt"))
            {
                this.addIntel(text, "Class", text, text);
            }
        }

        private void addMath()
        {
            foreach (string text in System.IO.File.ReadLines(this.defPath + "//classfunc.txt"))
            {
                this.addIntel(text, "Method", text, text);
            }
        }

        private void addBase()
        {
            foreach (string text in System.IO.File.ReadLines(this.defPath + "//base.txt"))
            {
                this.addIntel(text, "Keyword", text, text);
            }
        }

        private void Editor_Load(object sender, EventArgs e)
        {

        }

        private void execute_Click_1(object sender, EventArgs e)
        {
            
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            ForlornApi.Api.Inject();
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }

        private void status_MouseDown(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y);
        }

        private void status_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition;
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose;
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition;
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose;
            }
        }

        private void guna2Button9_Click(object sender, EventArgs e)
        {

        }


        private void openfile_Click(object sender, EventArgs e)
        {

        }

        private void savefile_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://discord.gg/bGWzu36P");
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Editor2_Load(object sender, EventArgs e)
        {

        }

        private void guna2Button8_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
            this.Hide();
        }

        private void Editor_Load_1(object sender, EventArgs e)
        {

        }


        private void guna2Separator1_Click(object sender, EventArgs e)
        {

        }



        private void guna2Button13_Click(object sender, EventArgs e)
        {
            HtmlDocument document = webBrowser1.Document;
            string scriptName = "GetText";
            object[] args = new string[0];
            object obj = document.InvokeScript(scriptName, args);
            string script = obj.ToString();
            ForlornApi.Api.ExecuteScript(script);
            ForlornApi.Api.ExecuteScript(Editor.Text);
        }

        private void guna2Button14_Click(object sender, EventArgs e)
        {
            webBrowser1.Document.InvokeScript("SetText", new object[]
{
    ""
});
        }

        private void guna2Button15_Click(object sender, EventArgs e)
        {
            HtmlDocument document = webBrowser1.Document;
            string scriptName = "GetText";
            object[] args = new string[0];
            object obj = document.InvokeScript(scriptName, args);
            string script = obj.ToString();
            SaveFileDialog Dialog = new SaveFileDialog
            {
                Title = "Save as",
                Filter = "Text (*.txt)|*.txt|Lua (*.lua)|*.lua|All Files (*.*)|*.*"
            };

            if (Dialog.ShowDialog() == DialogResult.OK)
            {
                if (!System.IO.File.Exists(Dialog.FileName))
                {
                    System.IO.File.Create(Dialog.FileName).Close();
                    System.IO.File.WriteAllText(Dialog.FileName, script);
                }
                else
                {
                    System.IO.File.WriteAllText(Dialog.FileName, script);
                }
            }
        }

        private void guna2Button16_Click(object sender, EventArgs e)
        {
            OpenFileDialog Dialog = new OpenFileDialog
            {
                Title = "Open",
                Filter = "Text (*.txt)|*.txt|Lua (*.lua)|*.lua|All Files (*.*)|*.*"
            };

            if (Dialog.ShowDialog() == DialogResult.OK)
            {
                webBrowser1.Document.InvokeScript("SetText", new object[]
                {
    System.IO.File.ReadAllText(Dialog.FileName)
                });
            }
        }

        private void webBrowser2_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void guna2Button7_Click(object sender, EventArgs e)
        {

        }

        private void realstatus_Click(object sender, EventArgs e)
        {

        }

        private void topMost_CheckedChanged(object sender, EventArgs e)
        {
            this.TopMost = topMost.Checked;
        }


        private void guna2ToggleSwitch1_CheckedChanged(object sender, EventArgs e)
        {
            if (guna2ToggleSwitch1.Checked)
            {
                this.Opacity = 0.75; 
            }
            else
            {
                this.Opacity = 1.0; 
            }
        }

        private void guna2HtmlLabel4_Click(object sender, EventArgs e)
        {

        }

        private void guna2HtmlLabel5_Click(object sender, EventArgs e)
        {

        }
    }
}
