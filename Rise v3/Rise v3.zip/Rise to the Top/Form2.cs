﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rise_to_the_Top
{
    public partial class Form2 : RoundedForm
    {

        public Point mouseLocation;

        public Form2()
        {
            InitializeComponent();
            Timer time = new Timer();
            time.Tick += timertick;
            time.Start();
            ForlornApi.Api.InitializeForlorn();
        }

        private void timertick(object sender, EventArgs e)
        {
            if (ForlornApi.Api.IsRobloxOpen())
            {
                robloxopen.Text = "Roblox Open: ✅";
                robloxopen.ForeColor = Color.LightGreen;  // Change text color to green
            }
            else
            {
                robloxopen.Text = "Roblox Open: ❌";
                robloxopen.ForeColor = Color.Red;  // Change text color to red
            }
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Close();
        }

        private void guna2CheckBox2_CheckedChanged(object sender, EventArgs e)
        {
            ForlornApi.Api.SetAutoInject(true);
        }

        private void guna2CheckBox2_unCheckedChanged(object sender, EventArgs e)
        {
            ForlornApi.Api.SetAutoInject(false);
        }

        private void guna2CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (guna2CheckBox1.Checked)
            {
                this.Opacity = 0.75;
            }
            else
            {
                this.Opacity = 1.0;
            }
        }


        private void guna2Button1_Click(object sender, EventArgs e)
        {
            ForlornApi.Api.KillRoblox();
        }

        private void guna2HtmlLabel2_MouseDown(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y);
        }

        private void guna2HtmlLabel2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition;
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose;
            }
        }

        private void robloxopen_Click(object sender, EventArgs e)
        {

        }

        private void guna2CheckBox3_CheckedChanged(object sender, EventArgs e)
        {
            this.TopMost = true;
        }

        private void guna2CheckBox3_unCheckedChanged(object sender, EventArgs e)
        {
            this.TopMost = false;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void guna2HtmlLabel2_MouseDown_1(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y);
        }

        private void guna2HtmlLabel2_MouseMove_1(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition;
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose;
            }
        }
    }
}
